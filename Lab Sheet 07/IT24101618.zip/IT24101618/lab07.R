setwd("C:\\Users\\miche\\OneDrive\\Desktop\\LabSheet07\\IT24101618")
# Exercise 1
a <- 10
b <- 25
total <- 40
p1 <- (b - a) / total
p1

# Exercise 2
lambda <- 1/3
p2 <- pexp(2, rate = lambda)
p2

# Exercise 3 (i)
p3_i <- 1 - pnorm(130, mean = 100, sd = 15)
p3_i

# Exercise 3 (ii)
p3_ii <- qnorm(0.95, mean = 100, sd = 15)
p3_ii
