setwd("C:\\Users\\miche\\OneDrive\\Desktop\\LabSheet07\\IT24101618")
#Exercise 
#Q1

#1)
n <- 50
p <- 0.85

#2)
prob_at_least_47 <- sum(dbinom(47:50, size = n, prob = p))
prob_at_least_47


#Q2

#1)
#number of customer calls received in a given time period

#2)
12

#3)
dpois(15,12)

